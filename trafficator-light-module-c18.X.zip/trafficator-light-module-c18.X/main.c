/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>        /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>       /* HiTech General Include File */
#elif defined(__18CXX)
    #include <p18cxxx.h>   /* C18 General Include File */
#endif

#if defined(__XC) || defined(HI_TECH_C)

#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#endif

#include "system.h"        /* System funct/params, like osc/peripheral config */

#include "user.h"          /* User funct/params, such as InitApp */
#include "ok-sound.h"

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/
int _direction;

int i = 0;
void Delay1Second(void);

void main(void) {

    ADCON1 = 0b00010100;
    TRISBbits.RB0 = 0;
    

    while(1) //infinite loop
    {
        PORTBbits.RB0 = 1;
        LATB0 = 1; //Set the PIN RB0 high
        Delay1Second();

    }
}

void Delay1Second()
{
    for(i=0;i<100;i++)
        __delay_ms(10);
}

/*
void main()
{
    InitApp();
    T0IF = 0;   // Clear the interrupt
    //int _49A_in_value = 0;
    int Reverse_in_value = 0;
    int R_ch_in_value = 0; 
    int L_ch_in_value = 0;
    
    while(1)
    {  
    R_ch_out = 0;
    L_ch_out = 0;
    _49A_out = 0;
    //_49A_in_value = GetADCValue(AN4);
    Reverse_in_value = GetADCValue(AN6);
   
    if (Reverse_in_value > 200)
    {
    ReversOn();                                 //--Turn reverse lights on--//
    return;
    }
    else   
        if (_49A_in == 0)   
        {
            Turn_49A();
        }
    else    if (_direction == 1)
            {
            AddRightBlinks();                     // Add 3 blinks to the right channel if left switch has been off//
            }
    else    if (_direction == 2)
            {
            AddLeftBlinks();                       // Add 3 blinks to the left channel if right switch has been off//
            }
    else    {
            R_ch_out = 0;
            L_ch_out = 0;
            _49A_out = 0;
            L_ch_in_value = 0; 
            R_ch_in_value = 0;
            Reverse_in_value = 0;
            _direction = 0;
            }
}
}

*/

//#pragma interrupt_level 2
/*void __interrupt() hi_isr()
{
    // a simple wait flag to wait for the time to feed the next sample into the PWM modulator
    // kinda like the sampling period.
	if(TMR2IF)
	{
		if(wait) wait--;

		TMR2IF = 0;
	}
}*/